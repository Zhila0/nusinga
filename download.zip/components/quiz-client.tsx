"use client";

import { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { Play } from 'lucide-react';

import type { Question } from '@/lib/questions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ProgressIndicator } from '@/components/progress-indicator';
import { CountdownCircle } from '@/components/countdown-circle';
import { ResultsScreen } from '@/components/results-screen';

const TIME_PER_QUESTION = 60;

interface QuizClientProps {
  questions: Question[];
}

export default function QuizClient({ questions }: QuizClientProps) {
  const [gameState, setGameState] = useState<'start' | 'playing' | 'finished'>('start');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([]);
  const [completedQuestions, setCompletedQuestions] = useState<boolean[]>([]);
  const [timeLeft, setTimeLeft] = useState(TIME_PER_QUESTION);
  const [timerKey, setTimerKey] = useState(0);

  const handleNextQuestion = useCallback(() => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setTimeLeft(TIME_PER_QUESTION);
      setTimerKey(prev => prev + 1);
    } else {
      setGameState('finished');
    }
  }, [currentQuestionIndex, questions.length]);

  useEffect(() => {
    if (gameState !== 'playing') return;

    if (timeLeft === 0) {
      setUserAnswers((prev) => {
        const newAnswers = [...prev];
        newAnswers[currentQuestionIndex] = null; // Record timeout as null answer
        return newAnswers;
      });
       setCompletedQuestions((prev) => {
        const newCompleted = [...prev];
        newCompleted[currentQuestionIndex] = true;
        return newCompleted;
      });
      handleNextQuestion();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prevTime) => prevTime - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, timeLeft, handleNextQuestion, currentQuestionIndex]);

  const handleStart = () => {
    setGameState('playing');
    setTimeLeft(TIME_PER_QUESTION);
    setCurrentQuestionIndex(0);
    setUserAnswers(new Array(questions.length).fill(undefined));
    setCompletedQuestions(new Array(questions.length).fill(false));
    setTimerKey(0);
  };

  const handleRestart = () => {
    handleStart();
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setUserAnswers((prev) => {
      const newAnswers = [...prev];
      newAnswers[currentQuestionIndex] = answerIndex;
      return newAnswers;
    });
    setCompletedQuestions((prev) => {
      const newCompleted = [...prev];
      newCompleted[currentQuestionIndex] = true;
      return newCompleted;
    });
    handleNextQuestion();
  };

  const currentQuestion = questions[currentQuestionIndex];

  if (gameState === 'start') {
    return (
      <Card className="w-full max-w-md text-center shadow-2xl">
        <CardHeader>
          <CardTitle className="text-4xl font-extrabold tracking-tight text-primary text-shadow">تاقیکردنەوەی بازنەیی</CardTitle>
          <CardDescription className="text-lg">زانینی خۆت تاقی بکەرەوە لەگەڵ کاتدا.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button size="lg" onClick={handleStart}>
            <Play className="ml-2" />
            دەستپێکردنی تاقیکردنەوە
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (gameState === 'finished') {
    return (
      <ResultsScreen
        questions={questions}
        userAnswers={userAnswers}
        onRestart={handleRestart}
      />
    );
  }

  return (
    <Card className="w-full max-w-5xl shadow-2xl overflow-hidden">
      <CardContent className="p-0">
        <div className="grid grid-cols-1 md:grid-cols-3 min-h-[70vh]">
          {/* Left Column */}
          <div className="col-span-1 bg-card-foreground/5 p-6 flex flex-col items-center justify-center gap-8 border-r">
            <CountdownCircle key={timerKey} timeLeft={timeLeft} totalTime={TIME_PER_QUESTION} />
            <ProgressIndicator
              totalQuestions={questions.length}
              currentQuestionIndex={currentQuestionIndex}
              completedQuestions={completedQuestions}
            />
          </div>

          {/* Right Column */}
          <div className="col-span-2 p-8 flex flex-col text-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestionIndex}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -30 }}
                transition={{ duration: 0.35, ease: "easeInOut" }}
                className="flex flex-col items-center justify-center gap-6 flex-grow"
              >
                <h2 className="text-2xl sm:text-3xl font-bold text-shadow text-right w-full">{currentQuestion.title}</h2>
                <div className="relative w-full aspect-video max-w-lg rounded-lg overflow-hidden shadow-lg mx-auto">
                  <Image
                    src={currentQuestion.image}
                    alt={currentQuestion.title}
                    fill
                    className="object-cover"
                    data-ai-hint={currentQuestion.imageHint}
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>
                <div className="flex flex-col gap-4 w-full max-w-lg mx-auto mt-4">
                  {currentQuestion.answers.map((answer, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="lg"
                      className="h-auto py-3 whitespace-normal justify-end text-right text-base bg-card text-card-foreground shadow-lg hover:bg-primary hover:text-primary-foreground hover:shadow-xl hover:-translate-y-1 transform-gpu transition-all duration-300 ease-in-out"
                      onClick={() => handleAnswerSelect(index)}
                    >
                      <span>{answer.text}</span>
                      <span className="font-bold ml-4">{String.fromCharCode(65 + index)}</span>
                    </Button>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
