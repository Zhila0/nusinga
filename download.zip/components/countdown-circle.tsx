"use client";

import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface CountdownCircleProps {
  timeLeft: number;
  totalTime: number;
}

export function CountdownCircle({ timeLeft, totalTime }: CountdownCircleProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const radius = 55;
  const circumference = 2 * Math.PI * radius;
  
  const progress = Math.max(0, Math.min(1, timeLeft / totalTime));
  const strokeDashoffset = circumference * (1 - progress);

  const timerColor =
    timeLeft <= 10
      ? 'stroke-destructive'
      : timeLeft <= 30
      ? 'stroke-warning'
      : 'stroke-primary';

  if (!isClient) {
    return (
      <div className="flex h-32 w-32 items-center justify-center rounded-full bg-muted/50">
        <span className="text-5xl font-bold text-muted-foreground">{totalTime}</span>
      </div>
    );
  }

  return (
    <div className="relative h-32 w-32">
      <svg className="h-full w-full -rotate-90" viewBox="0 0 120 120">
        <circle
          cx="60"
          cy="60"
          r={radius}
          className="stroke-muted/50"
          strokeWidth="10"
          fill="transparent"
        />
        <circle
          cx="60"
          cy="60"
          r={radius}
          className={cn('transition-stroke duration-1000 ease-linear', timerColor)}
          strokeWidth="10"
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-5xl font-bold text-foreground">{timeLeft}</span>
      </div>
    </div>
  );
}
