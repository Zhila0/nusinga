"use client";

import { useMemo } from 'react';
import { RotateCw, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

import type { Question } from '@/lib/questions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

interface ResultsScreenProps {
  questions: Question[];
  userAnswers: (number | null | undefined)[];
  onRestart: () => void;
}

export function ResultsScreen({ questions, userAnswers, onRestart }: ResultsScreenProps) {
  const score = useMemo(() => {
    return userAnswers.reduce((acc, answerIndex, questionIndex) => {
      if (answerIndex !== null && answerIndex !== undefined && questions[questionIndex]?.answers[answerIndex]?.isCorrect) {
        return acc + 1;
      }
      return acc;
    }, 0);
  }, [userAnswers, questions]);

  const percentage = Math.round((score / questions.length) * 100);

  return (
    <Card className="w-full max-w-2xl shadow-2xl text-right">
      <CardHeader className="text-center">
        <CardTitle className="text-4xl font-extrabold tracking-tight text-primary text-shadow">
          تاقیکردنەوەکە تەواو بوو!
        </CardTitle>
        <CardDescription className="text-lg">ئەوە ئەنجامی تۆیە.</CardDescription>
        <div className="py-4">
          <p className="text-5xl font-bold">{percentage}%</p>
          <p className="text-lg text-muted-foreground">
            تۆ وەڵامی {score} پرسیارت لە {questions.length} بە دروستی داوەتەوە.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <Separator className="my-4" />
        <h3 className="text-lg font-semibold mb-2 text-center">وەڵامەکانت</h3>
        <ScrollArea className="h-64">
          <div className="space-y-4 pl-4 text-right">
            {questions.map((question, index) => {
              const userAnswerIndex = userAnswers[index];
              const isAnswered = userAnswerIndex !== undefined && userAnswerIndex !== null;
              const isCorrect = isAnswered && question.answers[userAnswerIndex]?.isCorrect;
              const timedOut = userAnswerIndex === null;

              return (
                <div key={question.id} className="p-3 rounded-lg border bg-muted/50">
                  <p className="font-semibold mb-2">{index + 1}. {question.title}</p>
                  <div className="flex items-center justify-end gap-3">
                    <p className={cn(
                      timedOut && 'text-muted-foreground italic'
                    )}>
                      {timedOut 
                        ? 'وەڵام نەدراوەتەوە (کات تەواو بوو)' 
                        : isAnswered 
                        ? question.answers[userAnswerIndex].text 
                        : 'وەڵام نەدراوەتەوە'}
                    </p>
                    {timedOut ? (
                      <AlertCircle className="h-5 w-5 text-yellow-500 flex-shrink-0" />
                    ) : isCorrect ? (
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    ) : (
                      <XCircle className="h-5 w-5 text-destructive flex-shrink-0" />
                    )}
                  </div>
                  {(!isCorrect || timedOut) && (
                     <div className="flex items-center justify-end gap-3 mt-2 text-sm text-green-600">
                        <span>وەڵامی دروست: {question.answers.find(a => a.isCorrect)?.text}</span>
                        <CheckCircle className="h-4 w-4 flex-shrink-0" />
                     </div>
                  )}
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="justify-center">
        <Button size="lg" onClick={onRestart}>
          <RotateCw className="ml-2" />
          دووبارە یاری بکەرەوە
        </Button>
      </CardFooter>
    </Card>
  );
}
