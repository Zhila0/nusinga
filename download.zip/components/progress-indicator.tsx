"use client";

import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProgressIndicatorProps {
  totalQuestions: number;
  currentQuestionIndex: number;
  completedQuestions: boolean[];
}

export function ProgressIndicator({
  totalQuestions,
  currentQuestionIndex,
  completedQuestions,
}: ProgressIndicatorProps) {
  return (
    <div className="grid grid-cols-5 gap-3 p-4 bg-muted/30 rounded-lg">
      {Array.from({ length: totalQuestions }, (_, i) => {
        const isCompleted = completedQuestions[i];
        const isCurrent = i === currentQuestionIndex;

        return (
          <div
            key={i}
            className={cn(
              'flex h-10 w-10 items-center justify-center rounded-full border text-base font-bold transition-all duration-300',
              isCurrent
                ? 'bg-primary text-primary-foreground scale-110 shadow-lg'
                : isCompleted
                ? 'bg-foreground text-background'
                : 'bg-card text-card-foreground hover:bg-muted'
            )}
            style={{
              boxShadow: isCurrent ? '0 4px 14px 0 hsl(var(--primary) / 0.4)' : 'none',
            }}
          >
            {isCompleted && !isCurrent ? <Check className="h-5 w-5" /> : i + 1}
          </div>
        );
      })}
    </div>
  );
}
