import QuizClient from '@/components/quiz-client';
import { questions } from '@/lib/questions';
import { TrafficCone } from 'lucide-react';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="flex h-16 items-center justify-between border-b bg-card px-4 md:px-6">
        <div className="flex items-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-8 w-8 text-foreground"
          >
            <rect x="7" y="2" width="10" height="20" rx="3" />
            <circle cx="12" cy="7" r="1.5" fill="red" stroke="red" />
            <circle cx="12" cy="12" r="1.5" fill="yellow" stroke="yellow" />
            <circle cx="12" cy="17" r="1.5" fill="green" stroke="green" />
          </svg>
        </div>
        <h1 className="text-xl font-bold text-primary">نوسینگەی شێنێ</h1>
      </header>
      <main className="flex flex-1 w-full flex-col items-center justify-center p-4 sm:p-6 md:p-8">
        <QuizClient questions={questions} />
      </main>
    </div>
  );
}
