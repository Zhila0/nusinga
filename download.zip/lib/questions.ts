export interface Answer {
  text: string;
  isCorrect: boolean;
}

export interface Question {
  id: number;
  title: string;
  image: string;
  imageHint: string;
  answers: Answer[];
}

const sharedImage = "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg";

export const questions: Question[] = [
  {
    id: 1,
    title: "کام هەسارە بە هەسارەی سوور ناسراوە؟",
    image: sharedImage,
    imageHint: "planet mars",
    answers: [
      { text: "مەریخ", isCorrect: true },
      { text: "موشتەری", isCorrect: false },
      { text: "زوهره", isCorrect: false },
      { text: "کەیوان", isCorrect: false },
    ],
  },
  {
    id: 2,
    title: "گەورەترین زەریای سەر زەوی کامەیە؟",
    image: sharedImage,
    imageHint: "ocean wave",
    answers: [
      { text: "زەریای هێمن", isCorrect: true },
      { text: "زەریای ئەتڵەسی", isCorrect: false },
      { text: "زەریای هیندی", isCorrect: false },
      { text: "زەریای بەستەڵەکی باکوور", isCorrect: false },
    ],
  },
  {
    id: 3,
    title: "کێ 'کوشتنی باڵندە لاساییکەرەوەکە'ی نووسیوە؟",
    image: sharedImage,
    imageHint: "book stack",
    answers: [
      { text: "هارپەر لی", isCorrect: true },
      { text: "مارک تواین", isCorrect: false },
      { text: "ف. سکۆت فیتزجیرالد", isCorrect: false },
      { text: "جەین ئۆستن", isCorrect: false },
    ],
  },
  {
    id: 4,
    title: "هێمای کیمیایی بۆ زێڕ چییە؟",
    image: sharedImage,
    imageHint: "gold bars",
    answers: [
      { text: "Au", isCorrect: true },
      { text: "Ag", isCorrect: false },
      { text: "Pb", isCorrect: false },
      { text: "Fe", isCorrect: false },
    ],
  },
  {
    id: 5,
    title: "تاوەری ئیڤڵ لە کام شارە؟",
    image: sharedImage,
    imageHint: "paris city",
    answers: [
      { text: "پاریس", isCorrect: true },
      { text: "لەندەن", isCorrect: false },
      { text: "ڕۆما", isCorrect: false },
      { text: "بەرلین", isCorrect: false },
    ],
  },
  {
    id: 6,
    title: "سەختترین ماددەی سروشتی لەسەر زەوی چییە؟",
    image: sharedImage,
    imageHint: "diamond gem",
    answers: [
      { text: "ئەڵماس", isCorrect: true },
      { text: "کوارز", isCorrect: false },
      { text: "یاقوت", isCorrect: false },
      { text: "کۆرۆندۆم", isCorrect: false },
    ],
  },
  {
    id: 7,
    title: "کێ تابلۆی مۆنا لیزای کێشاوە؟",
    image: sharedImage,
    imageHint: "art gallery",
    answers: [
      { text: "لیۆناردۆ داڤینچی", isCorrect: true },
      { text: "ڤینسێنت ڤان گۆخ", isCorrect: false },
      { text: "پابلۆ پیکاسۆ", isCorrect: false },
      { text: "مایکل ئەنجیلۆ", isCorrect: false },
    ],
  },
  {
    id: 8,
    title: "پایتەختی ژاپۆن کامەیە؟",
    image: sharedImage,
    imageHint: "tokyo skyline",
    answers: [
      { text: "تۆکیۆ", isCorrect: true },
      { text: "کیۆتۆ", isCorrect: false },
      { text: "ئۆساکا", isCorrect: false },
      { text: "هیرۆشیما", isCorrect: false },
    ],
  },
  {
    id: 9,
    title: "چەند کیشوەر هەیە؟",
    image: sharedImage,
    imageHint: "world map",
    answers: [
      { text: "٧", isCorrect: true },
      { text: "٥", isCorrect: false },
      { text: "٦", isCorrect: false },
      { text: "٨", isCorrect: false },
    ],
  },
  {
    id: 10,
    title: "وێستگەی وزەی خانە چییە؟",
    image: sharedImage,
    imageHint: "science microscope",
    answers: [
      { text: "مایتۆکۆندریا", isCorrect: true },
      { text: "ناووک", isCorrect: false },
      { text: "ڕایبۆسۆم", isCorrect: false },
      { text: "سایتۆپلازم", isCorrect: false },
    ],
  },
  {
    id: 11,
    title: "درێژترین ڕووباری جیهان کامەیە؟",
    image: sharedImage,
    imageHint: "river winding",
    answers: [
      { text: "نیل", isCorrect: true },
      { text: "ئەمازۆن", isCorrect: false },
      { text: "یانگتزی", isCorrect: false },
      { text: "میسیسیپی", isCorrect: false },
    ],
  },
  {
    id: 12,
    title: "کام وڵات ماڵی کەنغەرە؟",
    image: sharedImage,
    imageHint: "australia outback",
    answers: [
      { text: "ئوستورالیا", isCorrect: true },
      { text: "ئەفریقای باشوور", isCorrect: false },
      { text: "هیندستان", isCorrect: false },
      { text: "بەڕازیل", isCorrect: false },
    ],
  },
  {
    id: 13,
    title: "پێکهاتەی سەرەکی لە گوکامۆلی چییە؟",
    image: sharedImage,
    imageHint: "avocado toast",
    answers: [
      { text: "ئەڤۆکادۆ", isCorrect: true },
      { text: "تەماتە", isCorrect: false },
      { text: "پیاز", isCorrect: false },
      { text: "گژنیژ", isCorrect: false },
    ],
  },
  {
    id: 14,
    title: "دراوی شانشینی یەکگرتوو چییە؟",
    image: sharedImage,
    imageHint: "london street",
    answers: [
      { text: "پاوەندی ستەرلینگ", isCorrect: true },
      { text: "یۆرۆ", isCorrect: false },
      { text: "دۆلار", isCorrect: false },
      { text: "یەن", isCorrect: false },
    ],
  },
  {
    id: 15,
    title: "کێ شانازیی داهێنانی تەلەفۆنی پێدەدرێت؟",
    image: sharedImage,
    imageHint: "vintage telephone",
    answers: [
      { text: "ئەلێکساندەر گراهام بێڵ", isCorrect: true },
      { text: "تۆماس ئەدیسۆن", isCorrect: false },
      { text: "نیکۆلا تێسلا", isCorrect: false },
      { text: "گولیلمۆ مارکۆنی", isCorrect: false },
    ],
  },
  {
    id: 16,
    title: "بچووکترین ژمارەی خۆبەش کامەیە؟",
    image: sharedImage,
    imageHint: "math chalkboard",
    answers: [
      { text: "٢", isCorrect: true },
      { text: "١", isCorrect: false },
      { text: "٣", isCorrect: false },
      { text: "٠", isCorrect: false },
    ],
  },
  {
    id: 17,
    title: "'CPU' کورتکراوەی چییە؟",
    image: sharedImage,
    imageHint: "computer motherboard",
    answers: [
      { text: "یەکەی ناوەندی چارەسەرکردن", isCorrect: true },
      { text: "یەکەی کەسی کۆمپیوتەر", isCorrect: false },
      { text: "یەکەی پرۆگرامی ناوەندی", isCorrect: false },
      { text: "یەکەی چارەسەرکردنی کۆنترۆڵ", isCorrect: false },
    ],
  },
  {
    id: 18,
    title: "لە چ ساڵێکدا تایتانیک نقوم بوو؟",
    image: sharedImage,
    imageHint: "ship ocean",
    answers: [
      { text: "١٩١٢", isCorrect: true },
      { text: "١٩٠٥", isCorrect: false },
      { text: "١٩١٨", isCorrect: false },
      { text: "١٩٢٣", isCorrect: false },
    ],
  },
  {
    id: 19,
    title: "گازی سەرەکی لە بەرگەهەوای زەویدا چییە؟",
    image: sharedImage,
    imageHint: "earth atmosphere",
    answers: [
      { text: "نایترۆجین", isCorrect: true },
      { text: "ئۆکسجین", isCorrect: false },
      { text: "دووەم ئۆکسیدی کاربۆن", isCorrect: false },
      { text: "ئارگۆن", isCorrect: false },
    ],
  },
  {
    id: 20,
    title: "گەورەترین ئێسکی لەشی مرۆڤ کامەیە؟",
    image: sharedImage,
    imageHint: "human skeleton",
    answers: [
      { text: "ئێسکی ڕان", isCorrect: true },
      { text: "ئێسکی باڵ", isCorrect: false },
      { text: "ئێسکیقولەپێ", isCorrect: false },
      { text: "کەللەسەر", isCorrect: false },
    ],
  },
  {
    id: 21,
    title: "کام هونەرمەند بە تابلۆی 'شەوی ئەستێرەکان' ناسراوە؟",
    image: sharedImage,
    imageHint: "starry sky",
    answers: [
      { text: "ڤینسێنت ڤان گۆخ", isCorrect: true },
      { text: "کلۆد مۆنێ", isCorrect: false },
      { text: "سەلڤادۆر دالی", isCorrect: false },
      { text: "ڕێمبرانت", isCorrect: false },
    ],
  },
  {
    id: 22,
    title: "کام توخم ژمارەی ئەتۆمی ١ ی هەیە؟",
    image: sharedImage,
    imageHint: "atom model",
    answers: [
      { text: "هایدرۆجین", isCorrect: true },
      { text: "هیلیۆم", isCorrect: false },
      { text: "ئۆکسجین", isCorrect: false },
      { text: "لیسیۆم", isCorrect: false },
    ],
  },
  {
    id: 23,
    title: "پایتەختی کەنەدا کام شارەیە؟",
    image: sharedImage,
    imageHint: "canada parliament",
    answers: [
      { text: "ئۆتاوا", isCorrect: true },
      { text: "تۆرۆنتۆ", isCorrect: false },
      { text: "ڤانکۆڤەر", isCorrect: false },
      { text: "مۆنتریال", isCorrect: false },
    ],
  },
  {
    id: 24,
    title: "لە میتۆلۆژیای یۆنانیدا، کێ خوداوەندی دەریا بوو؟",
    image: sharedImage,
    imageHint: "sea storm",
    answers: [
      { text: "پۆسایدن", isCorrect: true },
      { text: "زیوس", isCorrect: false },
      { text: "هادیس", isCorrect: false },
      { text: "ئەپۆلۆ", isCorrect: false },
    ],
  },
  {
    id: 25,
    title: "دوای ئاو، کام خواردنەوە زۆرترین خواردنەوەی لە جیهاندا هەیە؟",
    image: sharedImage,
    imageHint: "tea cup",
    answers: [
      { text: "چا", isCorrect: true },
      { text: "قاوە", isCorrect: false },
      { text: "شەربەتی پرتەقاڵ", isCorrect: false },
      { text: "بیرە", isCorrect: false },
    ],
  },
];
